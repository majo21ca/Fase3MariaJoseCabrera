﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Fase3majo
{
    public partial class Ingresodatos : Form
    {
        public double ReportesPila = 0.0;
        public int ReporteNpila = 0;
        public int ReporteNcCola = 0;
        public double ReporteSumaLista = 0.0;
        public int ReporteNlista = 0;
        public double Valor_subsidio = 0.0;
        public string Sisben = "";

        Stack<EstructuraDatosAfiliado> Pilaafiliado = new Stack<EstructuraDatosAfiliado>();
        Queue<EstructuraDatosAfiliado> Colaafiliado = new Queue<EstructuraDatosAfiliado>();
        List<EstructuraDatosAfiliado> Listaafiliado = new List<EstructuraDatosAfiliado>();
        public Ingresodatos()
        {
            InitializeComponent();
        }


        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtnombre.Text = "";
            txtreportedatos.Text = "";
            txtsalario.Text = "";
            txtvalorsubsidio.Text = "";
            dateTimePicker1.Text = "";
            cmbTipo.Text = "";
            cmbEstrato.Text = "";
            cmbTipo.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }
        public double Calcular_Subsidio(string Estrato, string Salario)
        {
            double[] subsidioSI = { 450000, 350000, 250000, 150000, 0, 0 };
            double[] subsidioNO = { 300000, 200000, 100000, 50000, 0, 0 };
            double subsidio = 0.0;
            int estrato = int.Parse(Estrato);
            double salario = double.Parse(Salario);

            if (this.radioButton1.Checked == true)
            {
                Sisben = "SI";
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    Sisben = "NO";
                }
            }
            if (Sisben == "SI")
            {
                subsidio = subsidioSI[estrato - 1];
                if (salario < 500000)
                {
                    subsidio = subsidio + 50000;
                }
            }
            if (Sisben == "NO")
            {
                subsidio = subsidioNO[estrato - 1];
                if (salario < 1000000)
                {
                    subsidio = subsidio + 150000;
                }
            }
            return subsidio;
        }

        private void btnregistrar_Click(object sender, EventArgs e)
        {
            if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("Por favor, seleccione si está afiliado al SISBEN.");
                return;
            }


            int estrato = int.Parse(cmbEstrato.Text);
            double salario = double.Parse(txtsalario.Text);
            bool afiliadoSISBEN = radioButton1.Checked;
            double valorSubsidio = Calcular_Subsidio(cmbEstrato.Text, txtsalario.Text);

            Valor_subsidio = Calcular_Subsidio(cmbEstrato.Text, txtsalario.Text);
            EstructuraDatosAfiliado miEstructura = new EstructuraDatosAfiliado
          (cmbTipo.Text, txtID.Text, txtnombre.Text, estrato, salario, afiliadoSISBEN, valorSubsidio, dateTimePicker1.Value);


            if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("Por favor, seleccione si está afiliado al SISBEN.");
                return;
            }
            txtvalorsubsidio.Text = Valor_subsidio.ToString();




            if (cmbTipo.Text == "Pila")
            {
                ReportesPila = ReportesPila + Valor_subsidio;
                this.Pilaafiliado.Push(miEstructura);
                dgpila.DataSource = null;
                dgpila.DataSource = this.Pilaafiliado.ToArray();
                dgpila.Refresh();
                this.tabEstructura.SelectedIndex = 0;
                MessageBox.Show("se agrego a la pila", "confirmado",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else if (cmbTipo.Text == "Cola")
            {
                ReporteNcCola = ReporteNcCola + 1;
                this.Colaafiliado.Enqueue(miEstructura);
                dgcola.DataSource = null;
                dgcola.DataSource = this.Colaafiliado.ToArray();
                dgcola.Refresh();
                this.tabEstructura.SelectedIndex = 1;
                MessageBox.Show("se agrego a la Cola", "confirmado",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (cmbTipo.Text == "Lista")
            {
                ReporteNlista = ReporteNlista + 1;
                ReporteSumaLista = ReporteSumaLista + miEstructura.ValorSubsidio;
                this.Listaafiliado.Add(miEstructura);
                dglista.DataSource = null;
                dglista.DataSource = this.Listaafiliado.ToArray();
                dglista.Refresh();
                this.tabEstructura.SelectedIndex = 2;
                MessageBox.Show("se agrego a la Lista", "confirmado",
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
                {
                    cmbTipo.Items.Clear();

                    cmbTipo.Items.AddRange(new string[] { "Pila", "Cola", "Lista" });
                }
            }

        }

        private void btnReporte1_Click(object sender, EventArgs e)
        {
            txtreporte.Text = this.ReporteNpila.ToString();
        }

        private void btnEliminar1_Click(object sender, EventArgs e)
        {
            if (this.Pilaafiliado.Count > 0)
            {
                if (MessageBox.Show("¿Va a eliminar el ultimo registro de la pila?",
                    "confirma", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    EstructuraDatosAfiliado miEstructura = this.Pilaafiliado.Pop();
                    ReportesPila = ReporteNpila - 1;
                    ReportesPila = ReportesPila = miEstructura.ValorSubsidio;
                    dgpila.DataSource = null;
                    dgpila.DataSource = this.Pilaafiliado.ToArray();
                    MessageBox.Show("Se elimino el registro", "confirmacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No hay registro para borrar", "confirmacion",
                     MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void btneliminar2_Click(object sender, EventArgs e)
        {
            if (this.Colaafiliado.Count > 0)
                if (MessageBox.Show("¿Va a eliminar el ultimo registro de la cola?",
                                    "confirma", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    EstructuraDatosAfiliado miEstructura = this.Colaafiliado.Dequeue();
                    ReporteNcCola = ReporteNcCola - 1;
                    dgcola.DataSource = null;
                    dgcola.DataSource = this.Colaafiliado.ToArray();
                    MessageBox.Show("Se elimino el registro", "confirmacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No hay registro para borrar en la cola", "confirmacion",
                     MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
        }

        private void btnReporte2_Click(object sender, EventArgs e)
        {
            txtreporte.Text = ReporteNcCola.ToString();
        }

        private void btnEliminar3_Click(object sender, EventArgs e)
        {
            if (this.Listaafiliado.Count > 0)
            {
                int tamaño = Listaafiliado.Count;

                if (MessageBox.Show("¿Va a eliminar el ultimo registro de la lista?", "confirmacion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                    == DialogResult.Yes)
                {
                    EstructuraDatosAfiliado miEstructura = Listaafiliado[tamaño - 1];

                    this.ReporteNlista = ReporteNlista - 1;
                    ReporteSumaLista = ReporteSumaLista - miEstructura.ValorSubsidio;
                    Listaafiliado.RemoveAt(tamaño - 1);
                    dglista.DataSource = null;
                    dglista.DataSource = this.Listaafiliado.ToArray();
                    MessageBox.Show("El ultimo registrode la lista se elimino", "confirmacion",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("no hay registro para borrar en la lista ", "confirmacion", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnreporte3_Click(object sender, EventArgs e)
        {
            txtreporte.Text = ReporteNlista.ToString();
        }
        private void combEstrato_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReporte3_Click_1(object sender, EventArgs e)
        {
            double resultado = ReporteSumaLista / ReporteNlista;
            txtreporte.Text = resultado.ToString();
        }

        private void btnreporte1_Click_1(object sender, EventArgs e)
        {
            txtreporte.Text = this.ReportesPila.ToString();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}

