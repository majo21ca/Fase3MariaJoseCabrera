﻿namespace Fase3majo
{
    partial class Ingresodatos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtreporte = new TextBox();
            label12 = new Label();
            button1 = new Button();
            label11 = new Label();
            btnsalir = new Button();
            btnlimpiar = new Button();
            btnregistrar = new Button();
            dateTimePicker1 = new DateTimePicker();
            txtsalario = new TextBox();
            txtID = new TextBox();
            txtreportedatos = new TextBox();
            txtvalorsubsidio = new TextBox();
            txtnombre = new TextBox();
            cmbTipo = new ComboBox();
            cmbEstrato = new ComboBox();
            combtipoID = new ComboBox();
            groupBoxsisben = new GroupBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label10 = new Label();
            tabEstructura = new TabControl();
            tabPage1 = new TabPage();
            btnreporte1 = new Button();
            btnEliminar1 = new Button();
            dgpila = new DataGridView();
            tabPage2 = new TabPage();
            btneliminar2 = new Button();
            btnReporte2 = new Button();
            dgcola = new DataGridView();
            tabPage3 = new TabPage();
            btnEliminar3 = new Button();
            btnReporte3 = new Button();
            dglista = new DataGridView();
            groupBox1.SuspendLayout();
            groupBoxsisben.SuspendLayout();
            tabEstructura.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgpila).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgcola).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dglista).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtreporte);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(btnsalir);
            groupBox1.Controls.Add(btnlimpiar);
            groupBox1.Controls.Add(btnregistrar);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(txtsalario);
            groupBox1.Controls.Add(txtID);
            groupBox1.Controls.Add(txtreportedatos);
            groupBox1.Controls.Add(txtvalorsubsidio);
            groupBox1.Controls.Add(txtnombre);
            groupBox1.Controls.Add(cmbTipo);
            groupBox1.Controls.Add(cmbEstrato);
            groupBox1.Controls.Add(combtipoID);
            groupBox1.Controls.Add(groupBoxsisben);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(41, 53);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(890, 341);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Datos del Afiliado";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // txtreporte
            // 
            txtreporte.Enabled = false;
            txtreporte.Location = new Point(501, 247);
            txtreporte.Name = "txtreporte";
            txtreporte.Size = new Size(100, 23);
            txtreporte.TabIndex = 26;
            txtreporte.TextChanged += textBox1_TextChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(387, 250);
            label12.Name = "label12";
            label12.Size = new Size(108, 15);
            label12.TabIndex = 25;
            label12.Text = "Reporte de Datos:";
            // 
            // button1
            // 
            button1.Location = new Point(681, 304);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 24;
            button1.Text = "Salir";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label11
            // 
            label11.Location = new Point(0, 0);
            label11.Name = "label11";
            label11.Size = new Size(100, 23);
            label11.TabIndex = 0;
            // 
            // btnsalir
            // 
            btnsalir.Location = new Point(0, 0);
            btnsalir.Name = "btnsalir";
            btnsalir.Size = new Size(75, 23);
            btnsalir.TabIndex = 1;
            // 
            // btnlimpiar
            // 
            btnlimpiar.Location = new Point(569, 304);
            btnlimpiar.Name = "btnlimpiar";
            btnlimpiar.Size = new Size(75, 23);
            btnlimpiar.TabIndex = 20;
            btnlimpiar.Text = "Limpiar";
            btnlimpiar.UseVisualStyleBackColor = true;
            btnlimpiar.Click += btnlimpiar_Click;
            // 
            // btnregistrar
            // 
            btnregistrar.Location = new Point(454, 304);
            btnregistrar.Name = "btnregistrar";
            btnregistrar.Size = new Size(75, 23);
            btnregistrar.TabIndex = 19;
            btnregistrar.Text = "Registrar";
            btnregistrar.UseVisualStyleBackColor = true;
            btnregistrar.Click += btnregistrar_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(646, 106);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 18;
            // 
            // txtsalario
            // 
            txtsalario.Location = new Point(454, 163);
            txtsalario.Name = "txtsalario";
            txtsalario.Size = new Size(100, 23);
            txtsalario.TabIndex = 17;
            // 
            // txtID
            // 
            txtID.Location = new Point(454, 54);
            txtID.Name = "txtID";
            txtID.Size = new Size(100, 23);
            txtID.TabIndex = 16;
            // 
            // txtreportedatos
            // 
            txtreportedatos.Location = new Point(0, 0);
            txtreportedatos.Name = "txtreportedatos";
            txtreportedatos.Size = new Size(100, 23);
            txtreportedatos.TabIndex = 22;
            // 
            // txtvalorsubsidio
            // 
            txtvalorsubsidio.Enabled = false;
            txtvalorsubsidio.Location = new Point(187, 220);
            txtvalorsubsidio.Name = "txtvalorsubsidio";
            txtvalorsubsidio.Size = new Size(100, 23);
            txtvalorsubsidio.TabIndex = 14;
            // 
            // txtnombre
            // 
            txtnombre.Location = new Point(187, 109);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(100, 23);
            txtnombre.TabIndex = 13;
            // 
            // cmbTipo
            // 
            cmbTipo.FormattingEnabled = true;
            cmbTipo.Items.AddRange(new object[] { "Pila ", "Cola", "Lista" });
            cmbTipo.Location = new Point(187, 271);
            cmbTipo.Name = "cmbTipo";
            cmbTipo.Size = new Size(121, 23);
            cmbTipo.TabIndex = 12;
            // 
            // cmbEstrato
            // 
            cmbEstrato.FormattingEnabled = true;
            cmbEstrato.Items.AddRange(new object[] { "1 ", "2", "3", "4", "5", "6" });
            cmbEstrato.Location = new Point(187, 163);
            cmbEstrato.Name = "cmbEstrato";
            cmbEstrato.Size = new Size(121, 23);
            cmbEstrato.TabIndex = 11;
            cmbEstrato.SelectedIndexChanged += combEstrato_SelectedIndexChanged;
            // 
            // combtipoID
            // 
            combtipoID.FormattingEnabled = true;
            combtipoID.Items.AddRange(new object[] { "CC", "TI", "Pasaporte" });
            combtipoID.Location = new Point(187, 54);
            combtipoID.Name = "combtipoID";
            combtipoID.Size = new Size(121, 23);
            combtipoID.TabIndex = 10;
            // 
            // groupBoxsisben
            // 
            groupBoxsisben.Controls.Add(radioButton1);
            groupBoxsisben.Controls.Add(radioButton2);
            groupBoxsisben.Location = new Point(592, 163);
            groupBoxsisben.Name = "groupBoxsisben";
            groupBoxsisben.Size = new Size(200, 53);
            groupBoxsisben.TabIndex = 9;
            groupBoxsisben.TabStop = false;
            groupBoxsisben.Text = "¿Afiliado a SISBEN?";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(6, 22);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(34, 19);
            radioButton1.TabIndex = 18;
            radioButton1.TabStop = true;
            radioButton1.Text = "SI";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(106, 22);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(43, 19);
            radioButton2.TabIndex = 19;
            radioButton2.Text = "NO";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(387, 57);
            label9.Name = "label9";
            label9.Size = new Size(37, 15);
            label9.TabIndex = 8;
            label9.Text = "*N ID";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(387, 163);
            label8.Name = "label8";
            label8.Size = new Size(56, 15);
            label8.TabIndex = 7;
            label8.Text = "*Salario$";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(517, 109);
            label7.Name = "label7";
            label7.Size = new Size(115, 15);
            label7.TabIndex = 6;
            label7.Text = "*Fecha de Afiliacion";
            // 
            // label6
            // 
            label6.Location = new Point(0, 0);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 23;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(49, 274);
            label5.Name = "label5";
            label5.Size = new Size(113, 15);
            label5.TabIndex = 4;
            label5.Text = "*Tipo de Estructura";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(49, 220);
            label4.Name = "label4";
            label4.Size = new Size(84, 15);
            label4.TabIndex = 3;
            label4.Text = "Valor Subsidio";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(49, 171);
            label3.Name = "label3";
            label3.Size = new Size(138, 15);
            label3.TabIndex = 2;
            label3.Text = "*Estrato Socieconomico";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(49, 117);
            label2.Name = "label2";
            label2.Size = new Size(115, 15);
            label2.TabIndex = 1;
            label2.Text = "*Nombre Completo";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(49, 57);
            label1.Name = "label1";
            label1.Size = new Size(132, 15);
            label1.TabIndex = 0;
            label1.Text = "*Tipo de Identificacion";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(469, 25);
            label10.Name = "label10";
            label10.Size = new Size(358, 17);
            label10.TabIndex = 9;
            label10.Text = "SISTEMA DE VALIDACION DE SUBSIDIO PARA AFILIADOS";
            label10.Click += label10_Click;
            // 
            // tabEstructura
            // 
            tabEstructura.Controls.Add(tabPage1);
            tabEstructura.Controls.Add(tabPage2);
            tabEstructura.Controls.Add(tabPage3);
            tabEstructura.Location = new Point(40, 386);
            tabEstructura.Name = "tabEstructura";
            tabEstructura.SelectedIndex = 0;
            tabEstructura.Size = new Size(872, 129);
            tabEstructura.TabIndex = 10;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnreporte1);
            tabPage1.Controls.Add(btnEliminar1);
            tabPage1.Controls.Add(dgpila);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(864, 101);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Pila";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnreporte1
            // 
            btnreporte1.Location = new Point(768, 15);
            btnreporte1.Name = "btnreporte1";
            btnreporte1.Size = new Size(75, 23);
            btnreporte1.TabIndex = 6;
            btnreporte1.Text = "Reporte";
            btnreporte1.UseVisualStyleBackColor = true;
            btnreporte1.Click += btnreporte1_Click_1;
            // 
            // btnEliminar1
            // 
            btnEliminar1.Location = new Point(768, 58);
            btnEliminar1.Name = "btnEliminar1";
            btnEliminar1.Size = new Size(75, 23);
            btnEliminar1.TabIndex = 5;
            btnEliminar1.Text = "Eliminar";
            btnEliminar1.UseVisualStyleBackColor = true;
            btnEliminar1.Click += btnEliminar1_Click;
            // 
            // dgpila
            // 
            dgpila.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgpila.Location = new Point(6, -5);
            dgpila.Name = "dgpila";
            dgpila.Size = new Size(737, 106);
            dgpila.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(btneliminar2);
            tabPage2.Controls.Add(btnReporte2);
            tabPage2.Controls.Add(dgcola);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(864, 101);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Cola";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // btneliminar2
            // 
            btneliminar2.Location = new Point(768, 72);
            btneliminar2.Name = "btneliminar2";
            btneliminar2.Size = new Size(75, 23);
            btneliminar2.TabIndex = 5;
            btneliminar2.Text = "Eliminar";
            btneliminar2.UseVisualStyleBackColor = true;
            btneliminar2.Click += btneliminar2_Click;
            // 
            // btnReporte2
            // 
            btnReporte2.Location = new Point(768, 23);
            btnReporte2.Name = "btnReporte2";
            btnReporte2.Size = new Size(75, 23);
            btnReporte2.TabIndex = 4;
            btnReporte2.Text = "Reporte";
            btnReporte2.UseVisualStyleBackColor = true;
            btnReporte2.Click += btnReporte2_Click;
            // 
            // dgcola
            // 
            dgcola.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgcola.Location = new Point(0, 3);
            dgcola.Name = "dgcola";
            dgcola.Size = new Size(737, 106);
            dgcola.TabIndex = 1;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(btnEliminar3);
            tabPage3.Controls.Add(btnReporte3);
            tabPage3.Controls.Add(dglista);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(864, 101);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Lista";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnEliminar3
            // 
            btnEliminar3.Location = new Point(774, 53);
            btnEliminar3.Name = "btnEliminar3";
            btnEliminar3.Size = new Size(75, 23);
            btnEliminar3.TabIndex = 3;
            btnEliminar3.Text = "Eliminar";
            btnEliminar3.UseVisualStyleBackColor = true;
            btnEliminar3.Click += btnEliminar3_Click;
            // 
            // btnReporte3
            // 
            btnReporte3.Location = new Point(774, 13);
            btnReporte3.Name = "btnReporte3";
            btnReporte3.Size = new Size(75, 23);
            btnReporte3.TabIndex = 4;
            btnReporte3.Text = "Reporte";
            btnReporte3.Click += btnReporte3_Click_1;
            // 
            // dglista
            // 
            dglista.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dglista.Location = new Point(0, 3);
            dglista.Name = "dglista";
            dglista.Size = new Size(737, 106);
            dglista.TabIndex = 1;
            // 
            // Ingresodatos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(988, 522);
            Controls.Add(tabEstructura);
            Controls.Add(label10);
            Controls.Add(groupBox1);
            Name = "Ingresodatos";
            Text = "Ingresodatos";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBoxsisben.ResumeLayout(false);
            groupBoxsisben.PerformLayout();
            tabEstructura.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgpila).EndInit();
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgcola).EndInit();
            tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dglista).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label10;
        private Label label11;
        private Button btnsalir;
        private Button btnlimpiar;
        private Button btnregistrar;
        private DateTimePicker dateTimePicker1;
        private TextBox txtsalario;
        private TextBox txtID;
        private TextBox txtreportedatos;
        private TextBox txtvalorsubsidio;
        private TextBox txtnombre;
        private ComboBox cmbTipo;
        private ComboBox cmbEstrato;
        private ComboBox combtipoID;
        private GroupBox groupBoxsisben;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private TabControl tabEstructura;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private DataGridView dgpila;
        private DataGridView dgcola;
        private TabPage tabPage3;
        private DataGridView dglista;
        private Button btnEliminar1;
        private Button btneliminar2;
        private Button btnReporte2;
        private Button btnEliminar3;
        private Button btnReporte3;
        private Button button1;
        private TextBox txtreporte;
        private Label label12;
        private Button btnreporte1;
    }
}