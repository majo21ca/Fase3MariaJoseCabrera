﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase3majo
{
    class EstructuraDatosAfiliado
    {
        private string text1;
        private string text2;
        private string text3;
        private string text4;
        private GroupBox groupBoxsisben;
        private string text5;
        private DateTime value;

        public string TipoID { get; set; }
        public string ID { get; set; }
        public string Nombre { get; set; }
        public int Estrato { get; set; }
        public double Salario { get; set; }
        public bool AfiliadoSISBEN { get; set; }
        public double ValorSubsidio { get; set; }
        public DateTime FechaAfiliacion { get; set; }
        public string Pila { get; set; }
        public string Cola { get; set; }
        public string Lista { get; set; }

        public EstructuraDatosAfiliado
            (
            string tipoID,
            string id,
            string nombre,
            int estrato,
            double salario,
            bool afiliadoSISBEN,
            double valorSubsidio,
            DateTime fechaAfiliacion
             )
        {
            TipoID = tipoID;
            ID = id;
            Nombre = nombre;
            Estrato = estrato;
            Salario = salario;
            AfiliadoSISBEN = afiliadoSISBEN;
            ValorSubsidio = valorSubsidio;
            FechaAfiliacion = fechaAfiliacion;
        }

        public EstructuraDatosAfiliado(string text1, string text2, string text3, string text4, GroupBox groupBoxsisben, string text5, DateTime value)
        {
            this.text1 = text1;
            this.text2 = text2;
            this.text3 = text3;
            this.text4 = text4;
            this.groupBoxsisben = groupBoxsisben;
            this.text5 = text5;
            this.value = value;
        }
    }
}





    

